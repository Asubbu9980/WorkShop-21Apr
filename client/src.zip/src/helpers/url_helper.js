
// Users

export const USERS = "/v1/user";
export const TRIP = "/trip";



