import { combineReducers } from "redux";






const rootReducer = combineReducers({
    // public

});

export default rootReducer;