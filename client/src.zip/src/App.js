import React from 'react';

//imoprt Route
import Route from './routes';
function App() {
  return (
    <React.Fragment>
      <Route />
    </React.Fragment>
  );
}

export default App;
